""" author: feezyhendrix

    this is for configuration files
    notes: make sure you configure the rules in firebase
 """

Config = {
    "password" : "generalpassword for each account created ",
    "firebase_url" : "database url",
    "proxy_server" : "input proxy_server" #213.168.210.76 sample proxy server to not let instagram block your ip
}
